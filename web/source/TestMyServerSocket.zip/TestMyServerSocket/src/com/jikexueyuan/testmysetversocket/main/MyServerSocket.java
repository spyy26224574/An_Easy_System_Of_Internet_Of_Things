package com.jikexueyuan.testmysetversocket.main;


public class MyServerSocket {

	public static void main(String[] args) {
		new ServerListener().start();
		
	}

}
